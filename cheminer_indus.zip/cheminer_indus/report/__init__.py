# -*- coding: utf-8 -*-
# cheminer_indus/report/__init__.py

from .pdf_generator import PDFGenerator

__all__ = ["PDFGenerator"]

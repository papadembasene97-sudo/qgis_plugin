"""
Module IA pour CheminerIndus
Prédiction de pollution et optimisation des visites
"""

__all__ = ['PollutionPredictor', 'VisitOptimizer', 'NetworkVisualizer3D']

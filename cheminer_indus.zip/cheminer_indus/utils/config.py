import os

PACKAGE_DIR = os.path.dirname(__file__)
ICONS_DIR = os.path.normpath(os.path.join(PACKAGE_DIR, '..', 'icons'))
FONTS_DIR = os.path.normpath(os.path.join(PACKAGE_DIR, '..', 'fonts'))
